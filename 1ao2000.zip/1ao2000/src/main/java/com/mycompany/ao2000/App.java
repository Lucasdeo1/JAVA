/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ao2000;

/**
 *
 * @author User
 */
public class App {

    public static void main(String[] args) {
        
        for( int i = 0; i<2000;i++){
            System.out.println(i+1);
        }
    }
}
