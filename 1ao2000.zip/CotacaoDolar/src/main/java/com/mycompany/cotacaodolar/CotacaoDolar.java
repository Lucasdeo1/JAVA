package com.mycompany.cotacaodolar;
import java.util.Scanner;

public class CotacaoDolar {

    public static void main(String[] args) {
        
        double dolar = 4.97;
        
        Scanner valor = new Scanner(System.in);
        
        System.out.println("Insira o valor em real para fazer a conversão e ver o valor em Dólar: ");
        
        double valorUser = valor.nextDouble();
        
        
        System.out.println("O valor de R$ "+valorUser+ " corresponde á $ "+valorUser*dolar );
        
        
    }
}
