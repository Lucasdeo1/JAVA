package com.mycompany.estoquemedio;

public class EstoqueMedio {

    public static void main(String[] args) {
        
        int quantidadeMinima = 10;
        int quantidadeMaxima = 50;
        
        double estoqueMedio = ( quantidadeMinima + quantidadeMaxima )/ 2;
        
        System.out.println("O estoque medio é "+estoqueMedio );
    }
}
