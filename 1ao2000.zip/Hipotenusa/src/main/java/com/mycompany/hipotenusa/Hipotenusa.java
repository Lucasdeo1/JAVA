package com.mycompany.hipotenusa;

public class Hipotenusa {

    public static int hipotenusa( int x, int y ){
        int res = (x*x) + (y*y);
        return res;
    }
    
    public static void main(String[] args) {
        
        int altura = 2;
        int base = 2;
        
        int hipo = hipotenusa( altura, base ); 
        System.out.println(hipo);
    }
}
