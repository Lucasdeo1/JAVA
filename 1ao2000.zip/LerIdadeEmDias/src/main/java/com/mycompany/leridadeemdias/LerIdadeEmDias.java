/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leridadeemdias;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class LerIdadeEmDias {

    public static void main(String[] args) {
        
        Scanner valor = new Scanner(System.in);
        int []num = new int[3];
                
                
        System.out.println("Quantos anos, meses e dias, respectivamente");
        for( int i=0; i<3; i++){
            System.out.println("Digite: " +(i+1));
            num[i] = valor.nextInt(); 
        }
        
        int res = ((num[0]*365)+ (num[1]*30)) + num[2] ;
        
        System.out.println("voce tem "+res+" dias de idade");
        
        
        
    }
}
