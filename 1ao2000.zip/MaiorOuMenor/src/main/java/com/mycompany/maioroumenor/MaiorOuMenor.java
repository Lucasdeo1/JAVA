package com.mycompany.maioroumenor;
import java.util.Scanner;

public class MaiorOuMenor {

    public static void main(String[] args) {
       
        Scanner valor = new Scanner(System.in);
        int []num = new int[2];
                
                
        for ( int i =0; i< 2; i++){
           System.out.println("Digite um valor " +(i+1)+":");
            num[i] = valor.nextInt(); 
        }
        
        if( num[0] > num[1]){
            System.out.println("valor 1 = "+num[0]+" é maior que valor 2 = "+num[1] );
        }else if( num[0] < num[1] ){
            System.out.println("valor 1 = "+num[0]+" é menor que valor 2 = "+num[1] );
        }else {
            System.out.println("o valor 1 = "+num[0]+" e o valor 2 = "+num[1]+" são exatamentes iguais" );
        }    
    }
}
