package com.mycompany.multiplosde10;

public class MultiplosDe10 {

    public static void main(String[] args) {
        for( int i = 0; i < 100; i++ ){
            if( i % 10 == 0 ){
                System.out.println(i+1+" multiplo de 10");
            }else {
                System.out.println(i+1);
            }
        }
    }
}
