package com.mycompany.ordemcrescente;

public class OrdemCrescente {

    public static void main(String[] args) {
        
        int prim=0, seg=0, ter=0, a = 7, b = 1, c = 3;
        
        if ( a > b && a >c){
            prim = a;
            if( b > c){
                seg = b;
                ter = c;
            }else {
                seg = c;
                ter = b;
            }     
        } else if( b > a && b > c) {
            prim = b;
            if( a > c) {
                seg = a;
                ter = c
            }else {
                seg = c;
                ter = b;        
            }
        } else {
            prim = c;
            if ( a > b){
                seg = a;
                ter = b;
            }else {
                seg = b;
                ter = a;
            }
        } 
        
        
        System.out.println(" "+prim+", "+seg+", "+ter);
        
    }
}
