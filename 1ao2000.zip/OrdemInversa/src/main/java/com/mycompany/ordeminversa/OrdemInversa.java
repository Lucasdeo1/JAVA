package com.mycompany.ordeminversa;

public class OrdemInversa {

    public static void main(String[] args) {
        
        int[] vetor= {1,2,3};
         
        
        for( int i= 0; i<vetor.length; i++){
            System.out.println(vetor[i]);
        }
        System.out.println("\n\n");
        for( int i = vetor.length-1; i>=0; i--){
            System.out.println(vetor[i]);
        }
    }
}
