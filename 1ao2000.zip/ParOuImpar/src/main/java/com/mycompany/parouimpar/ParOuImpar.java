package com.mycompany.parouimpar;

public class ParOuImpar {
    
    public static int verificaParOuImpar( int x ){
        if ( x % 2 == 0 ){
            return 1; // par
        }else {
            return 2; // impar 
        }
    } 

    public static void main(String[] args) {
        
        int x = 14;
        
        int res = verificaParOuImpar( x );
        
        if ( res == 1 ){
            System.out.println("par");
        }else {
            System.out.println("impar");
        }
    }
}
