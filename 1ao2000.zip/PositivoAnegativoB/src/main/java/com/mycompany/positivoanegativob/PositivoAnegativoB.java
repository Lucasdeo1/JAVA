package com.mycompany.positivoanegativob;
import java.util.Scanner;

public class PositivoAnegativoB {

    public static void main(String[] args) {
        
        Scanner valor = new Scanner(System.in);
        
        System.out.println("insira um valor: ");
        int num = valor.nextInt();

        if ( num > 0){
            System.out.println("VALOR POSITIVO");
        }else {
            System.out.println("VALOR NEGATIVO");
        }    
    }
}
