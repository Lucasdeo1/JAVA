package com.mycompany.quadrante;

public class Quadrante {
    
    public static int verificaQuadrante( int x, int y ){
        if( x > 0 && y > 0 ) {
            return 1;
        }else if ( x< 0 && y > 0 ){
            return 2;
        }else if( x < 0 && y < 0 ) {
            return 3;
        }else if ( x > 0 && y < 0 ) {
            return 4;
        }else {
            return 0;
        }
        
    }
    
    public static void main(String[] args) {
        int x = 10;
        int y = -5;

        int quadrante = verificaQuadrante(x, y);

        System.out.println("O ponto (" + x + ", " + y + ") está no quadrante " + quadrante);
 
    }
}
