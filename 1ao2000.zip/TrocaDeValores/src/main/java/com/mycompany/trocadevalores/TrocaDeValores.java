package com.mycompany.trocadevalores;

public class TrocaDeValores {

    public static void main(String[] args) {
        
        int a =2,b=1,c;
        
        c = a;
        a = b;
        b = c;
        
        System.out.println("valor de A: "+a+"\n"+"valor de B: "+b );
    }
}
