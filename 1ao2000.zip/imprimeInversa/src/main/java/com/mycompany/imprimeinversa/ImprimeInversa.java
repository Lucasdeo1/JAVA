package com.mycompany.imprimeinversa;


public class ImprimeInversa {

    public static void main(String[] args) {
        
        int[] vetor = {1,2,3,4};
        
        
        for ( int i= vetor.length-1; i>=0; i--){
            System.out.println(vetor[i]);
        }
        
    }
}
