package com.mycompany.lersovogais;
import java.util.Scanner;

public class LerSoVogais {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
         
        System.out.println("digite uma frase: ");
        String frase = scanner.nextLine();
        
        System.out.println("as vogais sao: ");
        
        for ( int i= 0; i < frase.length();i++){
            char letra = Character.toLowerCase(frase.charAt(i));
            if(letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u' ){
                System.out.println(letra);
            } 
        }
        scanner.close();
    }
}
