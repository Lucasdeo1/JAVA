package com.mycompany.realizaoquesepede;
import java.util.Scanner;

public class RealizaOqueSePede {

    public static void main(String[] args) {
        
        Scanner op = new Scanner(System.in);
        Scanner num= new Scanner(System.in);
 
        int opcao=0, num1=0, num2=0, res=0;
        do {
            System.out.println("1- Adicao\n2- Subtracao\n3- Multiplicacao\n4- Divisao\nDigite a opção desejada:");
            opcao = op.nextInt();
            
            if ( opcao == 1){
                System.out.println("Digite um primeiro valor:");
                num1 = num.nextInt();
                System.out.println("Digite um segundo valor:");
                num2 = num.nextInt();
                res = num1 + num2;
                System.out.println(" "+num1+" + "+" "+num2+" = "+res);
            } else if ( opcao == 2){
                System.out.println("Digite um primeiro valor:");
                num1 = num.nextInt();
                System.out.println("Digite um segundo valor:");
                num2 = num.nextInt();
                res = num1 - num2;
                System.out.println(" "+num1+" - "+" "+num2+" = "+res);
            } else if ( opcao == 3){
                System.out.println("Digite um primeiro valor:");
                num1 = num.nextInt();
                System.out.println("Digite um segundo valor:");
                num2 = num.nextInt();
                res = num1 * num2;
                System.out.println(" "+num1+" x "+" "+num2+" = "+res);
            }else if ( opcao == 4){
                System.out.println("Digite um primeiro valor:");
                num1 = num.nextInt();
                System.out.println("Digite um segundo valor:");
                num2 = num.nextInt();
                res = num1 / num2;
                System.out.println(" "+num1+" : "+" "+num2+" = "+res);
            }else {
                System.out.println(" opcao invalida");
            }
            
        }while ( opcao>1 && opcao<5 );
        
        
        
    }
}
