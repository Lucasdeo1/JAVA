package com.mycompany.repeticaode1a100decrescente;

public class RepeticaoDe1a100decrescente {

    public static void main(String[] args) {
        
        for(int i=100; i>0;i--){
            System.out.println(i);
        }
    }
}
